import { w as head } from "../../chunks/index.js";
function _layout($$renderer, $$props) {
  let { children } = $$props;
  head("12qhfyh", $$renderer, ($$renderer2) => {
    $$renderer2.title(($$renderer3) => {
      $$renderer3.push(`<title>PetCare.ai - Your Pet's Health, One Message Away</title>`);
    });
    $$renderer2.push(`<meta name="description" content="AI-powered pet health triage via WhatsApp. Get instant diagnosis and connect to verified vets in 2 minutes."/> <meta name="viewport" content="width=device-width, initial-scale=1"/> <meta property="og:title" content="PetCare.ai - Your Pet's Health, One Message Away"/> <meta property="og:description" content="AI-powered pet health triage via WhatsApp. Get instant diagnosis and connect to verified vets in 2 minutes."/> <meta property="og:type" content="website"/> <link rel="icon" href="/favicon.png"/>`);
  });
  children($$renderer);
  $$renderer.push(`<!---->`);
}
export {
  _layout as default
};
