

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.Dn1Wsfkd.js","_app/immutable/chunks/DtxkgFWZ.js","_app/immutable/chunks/DwbXyf5H.js","_app/immutable/chunks/CzKicDFG.js","_app/immutable/chunks/Du4rZT15.js","_app/immutable/chunks/CsKPZyEx.js","_app/immutable/chunks/BCk8SjW3.js"];
export const stylesheets = [];
export const fonts = [];
