

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.D9OyCGbC.js","_app/immutable/chunks/DtxkgFWZ.js","_app/immutable/chunks/DwbXyf5H.js","_app/immutable/chunks/CzKicDFG.js","_app/immutable/chunks/Du4rZT15.js","_app/immutable/chunks/DziRAO5m.js","_app/immutable/chunks/Crrgsc0D.js"];
export const stylesheets = [];
export const fonts = [];
